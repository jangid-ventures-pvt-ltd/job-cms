// config.js
module.exports = {
    jwtSecret: 'a2z2023jsonwebtokenkeyconfigjs', // Replace with your actual secret key
  };  